import data
from sandwich_maker import SandwichMaker
from cashier import Cashier


# Make an instance of other classes here
resources = data.resources
recipes = data.recipes
sandwich_maker_instance = #####
cashier_instance = ######




def main():
    ###  write the rest of the codes ###

if __name__=="__main__":
    main()
